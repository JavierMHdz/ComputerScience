a) Javier Jesus Macossay Hernandez
b) 9907093913
c) In the assignment I have implemented Dijkstra's Algorithm
d) I only have a code file "output.cpp." In that .cpp file I have 3 helper functions. dijkstraAlgo is where I implemented the main algorithm. printResult is to print the routing table to the user. Finally, nextHopFunc is to find the next hop that will be printed to the user in the routing table.
g) My program will crash is the first line of the .txt file is not the number of nodes in the graph.
h) I learned how to use the min heap in C++ from www.geeksforgeeks.org
